print(5 + 3)
print(11 - 3)
print(24 / 3)
print(4 * 2)

