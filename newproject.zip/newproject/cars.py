cars = ['bmw', 'audi', 'toyota', 'subaru']
print("Here is the unsorted list:")
print(cars)
print("\nHere is the sorted list:")
print(sorted(cars))
print("\nHere is the original list again:")
print(cars)
print(len(cars))
