first_name = "john"
last_name = "doe"
full_name = first_name + " " + last_name
print("Hello " + full_name.title() + ", would you like to learn some Python today?")
