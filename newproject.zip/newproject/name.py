name = "ada lovelace"
print(name.title())
print(name.upper())
print(name.lower())

first_name = "james"
last_name = "rosado"
full_name = first_name + " " + last_name
print(full_name)

message = "Hello, " + full_name.title() + "!"
print(message)
print("\n")
print("Python")
print("\tPython")
print("\n")
print("Languages:\n\tPython\n\tC\n\tJavaScript")

favorite_language = "'python "
print(favorite_language)
favorite_language.rstrip()
print(favorite_language)
