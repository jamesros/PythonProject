quote_attr = "albert einstein"
quote = '"A person who never made a mistake never tried anything new."'
print(quote_attr.title() + " once said, " + quote)

