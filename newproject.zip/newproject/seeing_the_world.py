fav_places = ['ireland', 'japan', 'italy', 'alaska', 'hawaii']
print("This is the original list of the places I would like to visit:")
print(fav_places)

print("\nThis is the same list in alphabetical Order:")
print(sorted(fav_places))

print("\nThis is the original list again:")
print(fav_places)

print("\nThis is the list in reverse order")
fav_places.reverse()
print(fav_places)

print("\nThis is the original list again:")
fav_places.reverse()
print(fav_places)

print("\nThis is the same list in alphabetical Order:")
fav_places.sort()
print(fav_places)
print("\nThis is the same list in reverse alphabetical Order:")
fav_places.reverse()
print(fav_places)