message = "This is boring"
print(message)

message = "Now it's not!"
print(message)

