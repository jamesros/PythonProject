message = "Hello Python world!"
print(message)

mesage ="Hello Python Crash Course world!"
print(mesage)