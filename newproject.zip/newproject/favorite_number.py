favnum = 3
#insert favorite number into string message
message = "My favorite number is " + str(favnum) + "!"
print(message)
