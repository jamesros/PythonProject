squad = ['kelly', 'justin', 'josh', 'kevin', 'faith']
print(squad[0].title())
print(squad[1].title())
print(squad[2].title())
print(squad[3].title())
print(squad[4].title())
