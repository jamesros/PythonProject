bicycles = ['trek', 'cannondale', 'redline', 'specialized',]
print(bicycles[0])
print(bicycles[0].title())
print(bicycles[-1])
message = "My first bicycle was a " + bicycles[0].title() + "."
print(message)