squad = ['kelly', 'justin', 'josh', 'kevin', 'faith']
message = " is a valuable member of the squad."
print(squad[0].title() + message)
print(squad[1].title() + message)
print(squad[2].title() + message)
print(squad[3].title() + message)
print(squad[4].title() + message)