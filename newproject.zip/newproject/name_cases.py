first_name = "john"
last_name = "doe"
full_name = first_name + " " + last_name
print(full_name.title())
print(full_name.upper())
print(full_name.lower())